import { NgModule } from '@angular/core';
import { DonationlibModule } from 'donationlib';

@NgModule({
    imports: [DonationlibModule]
})

export class DonationsModule {

}