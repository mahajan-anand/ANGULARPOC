import { NgModule } from '@angular/core';
import { MasterlibModule } from 'masterlib';

@NgModule({
    imports: [MasterlibModule]
})

export class MastersModule {

}